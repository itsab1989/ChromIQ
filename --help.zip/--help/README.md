# ChromIQ demo package — Unified Measurement Management

Built by `scripts/make_demo_package.py` from ChromIQ 3.14.8-beta.166, on 2026-08-06.

Every project here exists to raise one specific window from the model in [issue #130](https://github.com/itsab1989/ChromIQ/issues/130) — the specification is in the repository at `docs/design/unified_measurement_management.md`.

## Before you start

1. Unzip the package.
2. Copy the `Demo-*` folders into your ChromIQ folder (`~/ChromIQ/` on macOS and Linux, `Documents\ChromIQ\` on Windows). They are ordinary project folders.
3. Start ChromIQ and pick the project by name in the Profile-run bar.

**Nothing here needs an instrument.** Every step below is a button press and a window; no measurement is ever taken. Cancel is always safe, and where a step does change files, it says so and says where the originals go.

**Work on a copy.** Several steps deliberately archive files into `old/`. Keep the zip so you can put a project back to its starting state by copying it again.

## What is in the package

| Project | Chart made by | What it is for |
|---|---|---|
| `Demo-01-Chart-Only` | ChromIQ layout engine | §4 row 2 — a chart with nothing measured: no warning |
| `Demo-02-Partial-Measurement` | ChromIQ layout engine | §5 M-REPLACE-PARTIAL — starting over a partial measurement |
| `Demo-03-Complete-And-Profiled` | printtarg | §5 M-REPLACE-COMPLETE — starting over a finished measurement |
| `Demo-04-Mismatched` | ChromIQ layout engine | §5 / §3a M-TI3-MISMATCH — the measurement and the chart disagree |
| `Demo-05-Unreadable-Measurements` | ChromIQ layout engine | §3a header-only / empty — a measurement file with nothing in it |
| `Demo-06-Verification-History` | ChromIQ layout engine (run chart) + printtarg (verification chart) | §6e rows 5 and 6 — M-PROFILE-VERIFY |
| `Demo-07-Nothing-To-Lose` | targen only / images only | §4a row 1 — nothing on disk |
| `Demo-08-Many-Runs` | mixed — printtarg and ChromIQ layout engine | a project with a real history: six runs in every state at once |
| `Demo-09-Run-Descriptions` | ChromIQ layout engine | §1/§2 — each run's own description and chart notes |

**How to read the “Message expected” column.** A window can be one message with a paragraph or two appended to it — for example `M-CHART-PROFILING` is the window, and `M-CHART-NOPAGES` is a paragraph added inside it when the chart has no layout recipe. The first ID in a cell is the window; anything marked *(appended)* is a paragraph within that same window, not a second window. IDs marked *(PROPOSED)* are awaiting review and are listed in §M-PROPOSED of the model.

Verification charts are deliberately **smaller** than the run charts they sit under (48 patches against 224 in `Demo-06-Verification-History`), so the two are never confused on screen or on paper.

Patch counts are whatever `targen` produced: it rounds a requested count up to fit its generator, so the numbers quoted below are the ones you will actually see on screen.

## Demo-01-Chart-Only

*Chart made by: ChromIQ layout engine.*

**Messages this project should raise**

| ID | Headline as approved in the model |
|---|---|
| `M-VERIFY-NO-PROFILE` | This run has no profile to verify yet |

**Cases covered**

- §4 row 2 — a chart with nothing measured: no warning
- §6e row 1 — no profile yet: no warning

**Step by step**

| # | What to do, and what to expect | Message expected |
|---|---|---|
| 1 | Load the project, set Profile run = run 1, Run type = Profiling. | *none — silence is the expected result* |
| 2 | Press **Generate Chart**. *Expected: no warning at all* — nothing has been measured, so a new chart costs only a reprint. | *none — silence is the expected result* |
| 3 | Go to Build Profile. *Expected: no warning* — there is no profile to replace and no verification history. | *none — silence is the expected result* |
| 4 | Set Run type = **Verification** and go to the Measure tab. *Expected:* **Start Measurement is greyed out**, because this run has no verification chart — since beta.128 Start needs a laid-out chart, so the guard cannot be reached by pressing it. **Hover the greyed button**: its tooltip is the message, and it is the one for the state this run is in — no profile to verify yet. Sequence S1.2/S1.3; nothing is written. | `M-VERIFY-NO-PROFILE` |


## Demo-02-Partial-Measurement

*Chart made by: ChromIQ layout engine.*

**Messages this project should raise**

| ID | Headline as approved in the model |
|---|---|
| `M-REPLACE-PARTIAL` | This run already holds part of a measurement |
| `M-CHART-PROFILING` | This run already holds work made with the chart you are about to replace |

**Cases covered**

- §5 M-REPLACE-PARTIAL — starting over a partial measurement
- §4 chart + partial .ti3 (Profiling)

**Step by step**

| # | What to do, and what to expect | Message expected |
|---|---|---|
| 1 | Set Profile run = run 1, Run type = Profiling. | *none — silence is the expected result* |
| 2 | Go to Measure and press **Start Measurement**. *Expected:* “This run already holds part of a measurement”, saying **32 of the chart's 224 patches**, naming “Refine / resume existing measurement” and the measurement file. Press Cancel. | `M-REPLACE-PARTIAL` |
| 3 | Tick **Refine / resume existing measurement (-r)** and press Start Measurement again. *Expected: no window* — resuming adds to the readings instead of replacing them. | *none — silence is the expected result* |
| 4 | Untick it again, go to Create Chart and press **Generate Chart**. *Expected:* “This run already holds work made with the chart you are about to replace”, listing a measurement of 32 patches. Press Cancel. | `M-CHART-PROFILING` |


## Demo-03-Complete-And-Profiled

*Chart made by: printtarg.*

**Messages this project should raise**

| ID | Headline as approved in the model |
|---|---|
| `M-REPLACE-COMPLETE` | This chart is fully measured |
| `M-CHART-PROFILING` | This run already holds work made with the chart you are about to replace |
| `M-CHART-NOPAGES` | This chart's printed pages cannot be recreated |
| `M-VERIFY-NO-CHART` | No verification chart for this run yet |

**Cases covered**

- §5 M-REPLACE-COMPLETE — starting over a finished measurement
- §4 chart + complete .ti3 + profile (Profiling)
- §4a row 5 — pages that cannot be redrawn (M-CHART-NOPAGES)
- M-DUPLICATE-BLOCKED — Duplicate needs a .channels.json

**Step by step**

| # | What to do, and what to expect | Message expected |
|---|---|---|
| 1 | Set Profile run = run 1, Run type = Profiling. | *none — silence is the expected result* |
| 2 | Press **Start Measurement**. *Expected:* “This chart is fully measured”, All 210 patches have been read, and the warning that the profile beside it will no longer match. Press Cancel. | `M-REPLACE-COMPLETE` |
| 3 | Go to Create Chart and press **Generate Chart**. *Expected:* the chart warning listing **both** the finished measurement and the profile built from it, **plus** a paragraph saying the pages cannot be drawn again (this chart came from printtarg, so it has no layout recipe), **plus** an explanation that Duplicate is not available and which file is missing. Press Cancel. | `M-CHART-PROFILING`<br>`M-CHART-NOPAGES` *(appended)*<br>`M-DUPLICATE-BLOCKED` *(appended)* |
| 4 | Look at the Profile-run bar: the **Duplicate** button is greyed out, exactly as the message said. | *none — silence is the expected result* |
| 5 | Set Run type = **Verification** and go to the Measure tab. *Expected:* **Start Measurement is greyed out** — this run has a profile but no verification chart, and Start needs a laid-out chart. **Hover the greyed button**: the tooltip is the message, telling you to create the verification chart first. Sequence S1.3.

    *If you go on and create that chart, pressing Start then begins a real measurement — with an instrument connected you may first be told the chart was made for a different one, which is the instrument warning, not a guard.* | `M-VERIFY-NO-CHART` |
| 6 | In Build Profile, use its own **Load** button to open this run's .ti3 directly. *Expected: no window* — pressing Build Profile asks nothing, because the target is a file rather than a run (sequence S5.1). | *none — silence is the expected result* |


## Demo-04-Mismatched

*Chart made by: ChromIQ layout engine.*

**Messages this project should raise**

| ID | Headline as approved in the model |
|---|---|
| `M-TI3-MISMATCH` | This run's measurement and its chart do not match |

**Cases covered**

- §5 / §3a M-TI3-MISMATCH — the measurement and the chart disagree
- §3a B ≠ C — the file's header disagrees with its own rows

**Step by step**

| # | What to do, and what to expect | Message expected |
|---|---|---|
| 1 | Set Profile run = **run 1**, Run type = Profiling. | *none — silence is the expected result* |
| 2 | Press **Start Measurement**. *Expected:* “This run's measurement and its chart do not match” — 48 readings against 1 patches, the statement that ChromIQ cannot tell which of the two is wrong, and a pointer to “Restore Used Chart”. Resume is **not** offered. Press Cancel. | `M-TI3-MISMATCH` |
| 3 | Switch to **run 2** and press Start Measurement. *Expected:* the same window, plus the extra sentence that the file's own header disagrees with the rows it contains, so it may be damaged as well as mismatched. | `M-TI3-MISMATCH` |


## Demo-05-Unreadable-Measurements

*Chart made by: ChromIQ layout engine.*

**Messages this project should raise**

| ID | Headline as approved in the model |
|---|---|
| `M-REPLACE-UNCOUNTABLE` | This run already holds a measurement file |
| `M-CHART-CORRUPT` | The measurement file in this run cannot be read |

**Cases covered**

- §3a header-only / empty — a measurement file with nothing in it
- §4 — a corrupt or empty measurement when a chart is replaced
- §4 — the same, with a profile in the run as well
- S1.1 — no chart to measure: Start is not offered at all

**Step by step**

| # | What to do, and what to expect | Message expected |
|---|---|---|
| 1 | Set Profile run = **run 1** (a .ti3 that holds no readable data) and press **Start Measurement**. *Expected:* “This run already holds a measurement file”, saying ChromIQ cannot tell how many readings it contains and naming the file. It must **not** suggest Refine / resume — there is nothing to resume from. Press Cancel. | `M-REPLACE-UNCOUNTABLE` |
| 2 | Still in run 1, go to Create Chart and press **Generate Chart**. *Expected:* **“The measurement file in this run cannot be read”** — a window of its own, not the ordinary chart warning: a file with no readings has nothing to list, so there is no item list. It says the file goes to the run's “old” folder and to look at it there before measuring again. Press Cancel. | `M-CHART-CORRUPT` |
| 3 | Switch to **run 2** — the same corrupt file, but this run also has a profile. Press Generate Chart. *Expected:* the same window, **plus** the paragraph explaining that the profile moves to the “old” folder too and that nothing on disk then connects it to the chart it came from. Press Cancel. | `M-CHART-CORRUPT` |
| 4 | Switch to **run 3**, which has a patch list but no laid-out chart. *Expected:* **Start Measurement is greyed out**, and its tooltip says there is no laid-out chart to measure and where to make one — *no window*, because the condition is prevented rather than reported. Before beta.128 the button was available here and pressing it failed inside chartread. | *none — silence is the expected result* |


## Demo-06-Verification-History

*Chart made by: ChromIQ layout engine (run chart) + printtarg (verification chart).*

**Messages this project should raise**

| ID | Headline as approved in the model |
|---|---|
| `M-PROFILE-VERIFY` | The verification measurements in this run were made against the profile you are about to replace |
| `M-CHART-W4` | This would undo the whole run, not just its chart |
| `M-CHART-VERIFY` | The verification measurements already made in this run used the chart you are about to replace |

**Cases covered**

- §6e rows 5 and 6 — M-PROFILE-VERIFY
- §4 W4 — regenerating the chart of a run with a history
- §4 W5 — M-CHART-VERIFY, replacing the verification chart
- §6d — the “don't show this again for this run” checkbox

**Step by step**

| # | What to do, and what to expect | Message expected |
|---|---|---|
| 1 | Set Profile run = **run 1**, Run type = Profiling. | *none — silence is the expected result* |
| 2 | Go to Build Profile and press **Build Profile**. *Expected:* “The verification measurements in this run were made against the profile you are about to replace”, saying **4 dated verification measurements, going back to 2026-02-14**, with three buttons. Press Cancel. | `M-PROFILE-VERIFY` |
| 3 | Press Build Profile again, tick **Don't show this again for this run**, then press Cancel. *Expected:* Cancel never silences the question — press Build Profile once more and it is still there. | `M-PROFILE-VERIFY` |
| 4 | Press Build Profile, tick the box and press **Build here anyway**. *Expected:* the build runs; afterwards `runs/run1/old/` holds the previous profile and `runs/run1/verifications/old/` holds the four dated folders, both under the same timestamp. Nothing is deleted. | `M-PROFILE-VERIFY` |
| 5 | **Undo by re-copying the project from the zip**, then try the other branch: press Build Profile and choose **Duplicate the run and build there**. *Expected:* the bar's own Duplicate confirmation appears, the copy becomes the selected run, and run 1 keeps its profile and all four verifications. | `M-PROFILE-VERIFY` |
| 6 | Back on the original copy: Create Chart, Run type = Profiling, press **Generate Chart**. *Expected:* the W4 window — “This would undo the whole run, not just its chart” — naming the measurement, the profile **and** the 4 verifications. | `M-CHART-W4` |
| 7 | Set Run type = **Verification** and press Generate Chart. *Expected:* the W5 window — “The verification measurements already made in this run used the chart you are about to replace”, which before this release said nothing at all. | `M-CHART-VERIFY` |


## Demo-07-Nothing-To-Lose

*Chart made by: targen only / images only.*

**Cases covered**

- §4a row 1 — nothing on disk
- §4a row 2 — a patch list is not a chart
- §4a row 7 — page images with no chart behind them
- §4a row 8 — dot-files are the operating system's, not the chart's

**Step by step**

| # | What to do, and what to expect | Message expected |
|---|---|---|
| 1 | Try **Generate Chart** in each of the four runs in turn. | *none — silence is the expected result* |
| 2 | *Expected in every one: no warning.* run 1 is empty, run 2 has only a patch list (.ti1), run 3 has only page images, run 4 has only a `.DS_Store`. None of them holds work, so there is nothing a warning could protect. | *none — silence is the expected result* |


## Demo-08-Many-Runs

*Chart made by: mixed — printtarg and ChromIQ layout engine.*

**Messages this project should raise**

| ID | Headline as approved in the model |
|---|---|
| `M-CHART-PROFILING` | This run already holds work made with the chart you are about to replace |
| `M-CHART-W4` | This would undo the whole run, not just its chart |
| `M-CHART-NOPAGES` | This chart's printed pages cannot be recreated |
| `M-PROFILE-VERIFY` | The verification measurements in this run were made against the profile you are about to replace |
| `M-PREVIEW-PAUSED` | The live preview is not being re-drawn |
| `M-BUILD-ELSEWHERE` | This measurement is not in the run you have selected |

**Cases covered**

- a project with a real history: six runs in every state at once
- §6e row 4 — the silence is per run, not global
- §4 the whole table, run by run, in one project

**Step by step**

| # | What to do, and what to expect | Message expected |
|---|---|---|
| 1 | This is the project to keep open while you work through the others: every run is in a different state, so the same button produces a different window depending only on which run is selected. | *none — silence is the expected result* |
| 2 | run 1 — chart only. run 2 — partial measurement. run 3 — complete measurement. run 4 — measurement and profile. run 5 — measurement, profile and two verifications. run 6 — a printtarg chart with no layout recipe. | *none — silence is the expected result* |
| 3 | **run 1** — press **Generate Chart**. *Expected: no window* — nothing has been measured here. | *none — silence is the expected result* |
| 4 | **run 2** — press Generate Chart. *Expected:* the chart warning, listing a measurement. Press Cancel. | `M-CHART-PROFILING` |
| 5 | **run 3** — press Generate Chart. *Expected:* the same window with the full patch count. Press Cancel. | `M-CHART-PROFILING` |
| 6 | **run 4** — press Generate Chart. *Expected:* the same window, now listing the profile as well. Press Cancel. | `M-CHART-PROFILING` |
| 7 | **run 5** — press Generate Chart. *Expected:* the W4 window instead, because this run has a verification history. Press Cancel. | `M-CHART-W4` |
| 8 | **run 6** — press Generate Chart. *Expected:* the chart warning **plus** the paragraph about pages that cannot be redrawn, because this chart came from printtarg. Press Cancel. | `M-CHART-PROFILING`<br>`M-CHART-NOPAGES` *(appended)* |
| 9 | In **run 2**, turn on **Auto-update preview** in Create Chart and change a layout setting. *Expected:* a window saying the live preview is not being re-drawn, **once**; change more settings and only the log repeats it. Switch the option off and on again and the window returns once more. | `M-PREVIEW-PAUSED` |
| 10 | In run 5, silence the Build Profile question with the checkbox, then switch to a different run and press Build Profile there. *Expected:* it asks again — the silence is remembered for one run only, and only until you close ChromIQ. | `M-PROFILE-VERIFY` |
| 11 | Switch the bar to **run 5**, then use Build Profile's own **Load** button to open a DIFFERENT run's measurement (run 6's will do) and press **Build Profile**. *Expected:* ChromIQ says the measurement is not in the run you selected, and that the profile would be written beside it rather than into run 5. Press Cancel — switching “Profile run” away and back loads the selected run's own measurement again. | `M-BUILD-ELSEWHERE` |


## Demo-09-Run-Descriptions

*Chart made by: ChromIQ layout engine.*

**Cases covered**

- §1/§2 — each run's own description and chart notes
- §4/§4a — what the Profile Description is built from
- §7 — the {rundescription} marker on a printed sheet
- §3a — a calibration has a description of its own
- F1-F8 — every label the two rows can show, and when
- T1.4 — a New run is labelled N+1, the number the folder line shows

**Step by step**

| # | What to do, and what to expect | Message expected |
|---|---|---|
| 1 | This project is about telling runs apart. It has three runs, each already described, and a calibration with a description of its own. Nothing here needs an instrument. | *none — silence is the expected result* |
| 2 | Set Profile run = **run 1**, Run type = Profiling, and look at the Create Chart tab. *Expected:* the two boxes under the project name read **“Run 1 Description”** and **“Run 1 Chart Notes”**, filled in with this run's own text — “PhotoRag Baryta, gloss, large chart”. | *what the app shows — no window* |
| 3 | Switch to **run 2**. *Expected:* both boxes change to run 2's text, and the labels become “Run 2 …”. Switch back to run 1 and its text returns. Nothing is carried across. | *what the app shows — no window* |
| 4 | Switch to **run 3**, which has been left undescribed. *Expected:* both boxes are empty — this feature never invents text. | *what the app shows — no window* |
| 5 | With run 1 selected, go to **Calibration & Profiling**. *Expected:* “Profile Description (-D)” reads **Demo-09-Run-Descriptions-PhotoRag Baryta, gloss, large chart** — the project name and the run's description, joined by a hyphen. | *what the app shows — no window* |
| 6 | Switch to run 3 (no description). *Expected:* the Profile Description is just the project name, with **no trailing hyphen** — an empty part drops out along with its separator. | *what the app shows — no window* |
| 7 | Type your own text into Profile Description, then switch runs again. *Expected:* your text stays, whatever you do. It is yours from the moment you type it. Clear the box to hand it back to ChromIQ, and the suggestion returns. | *what the app shows — no window* |
| 8 | Set Run type = **Calibration** (switch calibration options on in Preferences first if the entry is missing). *Expected:* the boxes now read **“Calibration Description”** and **“Calibration Chart Notes”** — no run number, because a calibration is not a run — and they hold the calibration's own text, not run 1's. | *what the app shows — no window* |
| 9 | Switch back to Profiling. *Expected:* run 1's description and notes are back, untouched by the visit. | *what the app shows — no window* |
| 10 | With run 2 selected, set Run type = **Verification**. *Expected:* the notes box is now labelled **“Verification Chart Notes”** — it is editing the verification chart, which is a different sheet of paper from the run's own chart. The description above it still says **“Run 2 Description”**, because the verification belongs to run 2. | *what the app shows — no window* |
| 11 | Set Run type back to **Profiling**, still on run 2. *Expected:* the notes label returns to **“Run 2 Chart Notes”** immediately — you should not have to leave the tab and come back. | *what the app shows — no window* |
| 12 | Set Profile run = **New run**, Run type = Profiling. *Expected:* the boxes read **“Run 4 Description”** and **“Run 4 Chart Notes”** — the number of the run a Generate would create. Check it against the **“Location being edited”** line just under the bar: it says **/run4/**, and the two must always agree. | *what the app shows — no window* |
| 13 | Still on **New run**, set Run type = **Verification**. *Expected:* **“Run 4 Description”** and **“Verification Chart Notes”**. | *what the app shows — no window* |
| 14 | Set Run type = **Calibration** and look at the **“Location being edited”** line under the bar. *Expected:* it ends in **/cal/** — a calibration is not in a run, so it must not name one. Switch back to Profiling and it names the run folder again. | *what the app shows — no window* |
| 15 | **The text you type for a run that does not exist yet.** Set Profile run = **New run**, Run type = Profiling, and type something into BOTH boxes. Before pressing anything else, look at runs 1, 2 and 3 in turn. *Expected:* none of them has taken your text — it belongs to the run you are about to make. Come back to New run: your text is still in the boxes. | *what the app shows — no window* |
| 16 | Now press **Generate Chart**. *Expected:* the new run is created, the labels change to its real number — and **both boxes still hold what you typed**, now saved to that run. Switch to another run and back to prove it is on disk. | *what the app shows — no window* |
| 17 | **The same for a calibration.** Set Run type = **Calibration**, type into both boxes, and press **Generate Chart**. *Expected:* the chart is made and **both boxes still hold your text**. Any previous calibration is moved into `cal/old/<date>/`, and a copy of your description goes with it so the archive says what it was. | *what the app shows — no window* |
| 18 | **Duplicate, then generate.** Select a run that has a chart and press **Duplicate** in the bar. When the copy is showing, press **Generate Chart**. *Expected:* it generates. There must be NO “This chart is loaded from elsewhere” window — the copy is this project's own chart, not somebody else's. | *what the app shows — no window* |
| 19 | In Create Chart (Manual), open the layout options and use **Insert ▾** to put **{rundescription}** into the sheet text, then press **Generate Chart**. *Expected:* the run's description is printed on the sheet. On a run with no description the marker prints nothing at all, which is why a saved layout is safe to reuse. | *what the app shows — no window* |
| 20 | Use **Duplicate** on run 1 — the button is in the bar above the tabs. *Expected:* ChromIQ confirms the duplicate first, and the new run's description then begins **“(copy) ”**, at the START of the box where you can see it without scrolling. | *not in §M — an existing guard window; reported as a gap in the model* |
| 21 | **The Profile Description belongs to one run.** With run 3 selected, go to the profiling tab and type your own text into **Profile Description**. Switch to run 1. *Expected:* run 1 shows ITS own name — the project name and run 1's description — not what you typed for run 3. Switch back to run 3 and your text is there. | *what the app shows — no window* |
| 22 | Still on run 3, **empty** the Profile Description box. *Expected:* the automatic name comes back for run 3, and it follows that run's description if you change it. Emptying the box is how you hand the name back to ChromIQ. | *what the app shows — no window* |
| 23 | Set Run type = **Calibration** and look at Profile Description. *Expected:* it reads **project name – Calibration Description**, built automatically, and it follows the Calibration Description as you change it. Type your own text there and it sticks to the calibration alone. | *what the app shows — no window* |
| 24 | **Restore Used Chart puts the notes back — for all three.** For a run, for Run type = Verification and for Run type = Calibration in turn: change the Chart Notes, press **Generate Chart**, then press **Restore Used Chart**. *Expected:* the notes of the chart that comes back are the ones on screen, in every one of the three cases. | *what the app shows — no window* |
| 25 | Set Run type = **Calibration** on a project whose `cal/` folder holds no chart, and press **Generate Chart**. *Expected:* it generates. There must be NO window saying you already made a calibration chart — you have not. | *what the app shows — no window* |


## Every message in the model, and where to see it

Knut asked for the package to *"detect every occurrence of messages"*. This table is generated from the model's catalogue, so a message that exists and is not exercised here shows up as a gap rather than being quietly missed.

| Message | Where in this package |
|---|---|
| `M-BUILD-ELSEWHERE` | `Demo-08-Many-Runs` step 11 |
| `M-CHART-CORRUPT` | `Demo-05-Unreadable-Measurements` step 2<br>`Demo-05-Unreadable-Measurements` step 3 |
| `M-CHART-NOPAGES` | `Demo-03-Complete-And-Profiled` step 3<br>`Demo-08-Many-Runs` step 8 |
| `M-CHART-PROFILING` | `Demo-02-Partial-Measurement` step 4<br>`Demo-03-Complete-And-Profiled` step 3<br>`Demo-08-Many-Runs` step 4<br>`Demo-08-Many-Runs` step 5<br>`Demo-08-Many-Runs` step 6<br>`Demo-08-Many-Runs` step 8 |
| `M-CHART-VERIFY` | `Demo-06-Verification-History` step 7 |
| `M-CHART-W4` | `Demo-06-Verification-History` step 6<br>`Demo-08-Many-Runs` step 7 |
| `M-DUPLICATE-BLOCKED` | `Demo-03-Complete-And-Profiled` step 3 |
| `M-NO-INSTRUMENT` | — *not exercised* |
| `M-PREVIEW-PAUSED` | `Demo-08-Many-Runs` step 9 |
| `M-PROFILE-VERIFY` | `Demo-06-Verification-History` step 2<br>`Demo-06-Verification-History` step 3<br>`Demo-06-Verification-History` step 4<br>`Demo-06-Verification-History` step 5<br>`Demo-08-Many-Runs` step 10 |
| `M-REPLACE-COMPLETE` | `Demo-03-Complete-And-Profiled` step 2 |
| `M-REPLACE-PARTIAL` | `Demo-02-Partial-Measurement` step 2 |
| `M-REPLACE-UNCOUNTABLE` | `Demo-05-Unreadable-Measurements` step 1 |
| `M-TI3-MISMATCH` | `Demo-04-Mismatched` step 2<br>`Demo-04-Mismatched` step 3 |
| `M-VERIFY-NO-CHART` | `Demo-03-Complete-And-Profiled` step 5 |
| `M-VERIFY-NO-PROFILE` | `Demo-01-Chart-Only` step 4 |

## Every sequence in §S, and where to see it

The model's §S lists what happens, in what order, for every entry condition. Each row below is one of those sequences. The ones that cannot be driven from a demo project say why — they need an instrument on the desk or a reading in progress, which no set of files can supply.

| Sequence | Where in this package | If not: why |
|---|---|---|
| `S1.1` | `Demo-05-Unreadable-Measurements` — run 3 — Start is greyed out | |
| `S1.2` | `Demo-01-Chart-Only` — run 1 with Run type = Verification — no profile to verify; met as the greyed Start button's tooltip, since Start needs a chart | |
| `S1.3` | `Demo-03-Complete-And-Profiled` — run 1 with Run type = Verification — a profile, but no verification chart; likewise the greyed Start button's tooltip | |
| `S1.4` | `Demo-01-Chart-Only` — run 1 — a chart with no measurement | |
| `S1.5` | `Demo-02-Partial-Measurement` — run 1 with Refine / resume ticked | |
| `S1.6` | `Demo-02-Partial-Measurement` — run 1 with Refine / resume clear | |
| `S1.7` | `Demo-03-Complete-And-Profiled` — run 1 | |
| `S1.8` | `Demo-04-Mismatched` — run 1 and run 2 | |
| `S1.9` | — | the instrument cannot be opened — hardware |
| `S2.1` | — | a patch being read — hardware |
| `S2.10` | — | a second failure arriving while a window is open — the instrument has to produce both |
| `S2.2` | — | a reading failure — hardware |
| `S2.3` | — | two reading failures in succession — hardware |
| `S2.4` | — | Stop pressed with nothing read — needs a live session |
| `S2.5` | — | Stop pressed mid-read — needs a live session |
| `S2.6` | — | the same window from the keyboard — needs a live session |
| `S2.7` | — | a Give-Up window — hardware |
| `S2.8` | — | controls disabled during a read — needs a live session |
| `S2.9` | — | one failure reported twice, printed and as an event — the instrument has to produce the failure |
| `S3.1` | — | reading the file a session wrote — needs a live session |
| `S3.2` | — | a session that saved nothing — needs a live session |
| `S3.3` | — | a resume that ended smaller — needs a live session |
| `S3.4` | `Demo-04-Mismatched` — run 2 — B ≠ C, reported and never resumed | |
| `S3.5` | — | the count added by a session — needs a live session |
| `S3.6` | `Demo-06-Verification-History` — the four dated folders are the result of this step | |
| `S3.7` | `Demo-06-Verification-History` — Tools → Measurement Report | |
| `S4.1` | `Demo-07-Nothing-To-Lose` — run 1 — nothing to displace | |
| `S4.2` | `Demo-01-Chart-Only` — run 1 — chart only | |
| `S4.3` | `Demo-02-Partial-Measurement` — run 1 | |
| `S4.4` | `Demo-06-Verification-History` — run 1 — W4 | |
| `S4.5` | `Demo-06-Verification-History` — run 1, Run type = Verification | |
| `S4.6` | `Demo-03-Complete-And-Profiled` — run 1 — Duplicate unavailable | |
| `S5.1` | `Demo-03-Complete-And-Profiled` — open its .ti3 with Build Profile's own Load button, so the target is a file rather than a run | |
| `S5.2` | `Demo-03-Complete-And-Profiled` — run 1 — no verification chart | |
| `S5.3` | `Demo-06-Verification-History` — run 1 | |
| `S5.4` | `Demo-06-Verification-History` — run 1, after ticking the box | |
| `S5.5` | `Demo-03-Complete-And-Profiled` — run 1 — Duplicate unavailable | |

**22 of 37 sequences can be driven from these projects.** The rest are listed above with the reason; they are covered by the automated suite instead, which replays a simulated instrument.

## What this package deliberately does not cover

Knut, #130: *"Some warnings cannot be reproduced, as they are hardware issues, so these are ignored."* These need an instrument on the desk and a reading in progress, so no demo project can raise them:

| Case | Why it cannot be in a demo project |
|---|---|
| §1 rows 1–4, 6–12 — every way a measurement can end (M-END) | needs a reading session in progress |
| §1 row 5 — ending with nothing read (M-END-EMPTY) | needs a reading session in progress |
| §3a / §2a — the file a session wrote holds no readings (M-TI3-EMPTY) | needs a session that ends before the first patch is read |
| §3b — a resume ended with fewer readings than it started with (M-TI3-SHRANK) | needs a resumed session against a real instrument |
| §7 — instrument, calibration and strip-reading events | all of them come from the instrument itself |

They are covered by the automated suite instead — `tests/test_unified_ending.py`, `tests/test_measurement_session.py` and `tests/test_session_guard_wiring.py` drive those paths with a replayed instrument.
